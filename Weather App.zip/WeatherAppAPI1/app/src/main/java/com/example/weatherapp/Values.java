package com.example.weatherapp;

public class Values {
    private Values(){/*To ensure that its object is not instantiated*/}
    public static final String API_KEY = "d213503c3ee387079c2025e805bb8def";
    public static final String KEY_RECORDS_BOOK = "KEY_RECORDS_BOOK";
}
